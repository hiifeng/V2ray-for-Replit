######################################################################
#######                 V2ray for Replit                         #####
####### Create By xiaowansm          Modlfy By ifeng             #####
####### Web Site:https://www.hicairo.com                         #####
####### Telegram:https://t.me/HiaiFeng                           #####
######################################################################

使用方法：
点击顶部的"Run"按钮后，左侧Files菜单中，程序自动创建url.txt文件，该文件包含VMess和VLess协议的链接地址，在客户端软件中导入即可。
同时，程序自动创建了VLess.png和VMess.png文件，分别是VLess和VMess协议的二维码，使用手机扫描即可添加节点。

更换节点中的UUID（用户ID）：
1、点击左侧Tools菜单中的Shell按钮，打开Shell窗口，运行create_UUID.sh脚本，程序会在左侧Files菜单中，创建uuid.txt文件，该文件中包含有新生成的UUID。
2、重启应用后生效，同时新生成的节点链接包含在url.txt文件中。
3、也可以使用第三方工具（https://www.v2fly.org/awesome/tools.html）生成UUID，然后手动打开uuid.txt文件，替换文件中的内容。

注意：
服务启动，copy节点信息后，请手动删除url.txt、uuid.txt、VLess.png及VMess.png文件。否则，你的节点任何人都可以使用。

问题反馈与交流：
在使用过程中，如果遇到问题，请使用Telegram与我联系。（https://t.me/HiaiFeng）